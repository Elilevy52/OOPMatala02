module ELI_LEVY_ID206946790_PART02 {
	requires javafx.controls;
	
	opens application to javafx.graphics, javafx.fxml;
}
